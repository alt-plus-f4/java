interface IRequirement {
    void take(Player player) throws Exception;
}