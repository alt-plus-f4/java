interface IReward {
    void reward(Player player);
}