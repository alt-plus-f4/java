public class PlusOperator extends BinaryOperation {
    PlusOperator(float a, float b){
        this.perform(a, b);
    }
    @Override
    public float perform(float a, float b) {
        return a + b;
    }
}
