import java.util.Stack;
import java.util.Vector;

public class Calculator {
    Vector<Operation> operations = new Vector<Operation>();

    Stack<Float> stack;

    void addOperation(Operation operation){
        operations.add(operation);
    }

    float evaluate(String input){
        String[] characters = input.split(" ");
        for(String character: characters){
            if(character.matches("-?\\d+(\\.\\d+)?")){ // if number
                stack.push(Float.parseFloat(character));
            }
            else{
                switch(character){
                    case "+": addOperation(new PlusOperator(stack.pop(), stack.pop()));
                    case "-": addOperation(new PlusOperator(stack.pop(), stack.pop()));
                    case "*": addOperation(new PlusOperator(stack.pop(), stack.pop()));
                    case "/": addOperation(new PlusOperator(stack.pop(), stack.pop()));
                    default:
                        System.out.println("OLLOLEKE |GAYINS");;
                }
            }
        }

        return 0;
    }

}
