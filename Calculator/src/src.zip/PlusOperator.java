public class PlusOperator extends BinaryOperation {
    @Override
    public float perform(float a, float b) {
        return a + b;
    }
}
