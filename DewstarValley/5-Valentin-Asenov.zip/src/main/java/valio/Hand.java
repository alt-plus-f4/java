package valio;

class Hand extends Instrument {
    public Hand(String name) {
        super(name);
    }
}
