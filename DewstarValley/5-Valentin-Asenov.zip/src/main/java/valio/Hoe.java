package valio;

class Hoe extends Instrument {
    public Hoe(String name) {
        super(name);
    }
}



