package valio;

public enum TypesOfSeeds {
    TREE,
    SEED
}
