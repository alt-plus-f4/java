package valio;

class Axe extends Instrument {
    public Axe(String name) {
        super(name);
    }
}