package valio;

public enum TypeOfCells {
    EMPTY,
    BLOCKED,
    TILLED,
    PLANTEDTREE,
    PLANTEDSEED,
}
