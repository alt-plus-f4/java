interface Machine {
    void push(Shape shape);
    Shape pull();
}