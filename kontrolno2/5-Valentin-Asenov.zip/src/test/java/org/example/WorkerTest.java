package org.example;

import static org.junit.jupiter.api.Assertions.*;

class WorkerTest {



}